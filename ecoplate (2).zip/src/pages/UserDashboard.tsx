import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  MapPin, 
  Leaf, 
  LogOut, 
  ShoppingBag, 
  Clock, 
  Droplets, 
  Wind, 
  CheckCircle2,
  Filter,
  Package,
  BrainCircuit
} from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { collection, query, where, onSnapshot, doc, getDoc, updateDoc, addDoc, serverTimestamp, setDoc, writeBatch } from 'firebase/firestore';
import { FoodListing, Order, SustainabilityImpact } from '../types';
import { useAuth } from '../components/AuthProvider';
import { calculateSmartDiscount, getTimerColor, formatTimeLeft, cn } from '../lib/utils';

export default function UserDashboard() {
  const { profile } = useAuth();
  const [listings, setListings] = useState<FoodListing[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [impact, setImpact] = useState<SustainabilityImpact>({ mealsSaved: 0, co2Reduced: 0, waterSaved: 0 });
  const [activeTab, setActiveTab] = useState<'listings' | 'orders'>('listings');
  const [maxPrice, setMaxPrice] = useState<number>(50);
  const [search, setSearch] = useState('');

  // Fetch Available Listings
  useEffect(() => {
    const q = query(collection(db, 'listings'), where('status', '==', 'available'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as FoodListing[];
      setListings(docs);
    });
    return () => unsubscribe();
  }, []);

  // Fetch User Orders
  useEffect(() => {
    if (!auth.currentUser) return;
    const q = query(collection(db, 'orders'), where('userId', '==', auth.currentUser.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as Order[];
      setOrders(docs);
    });
    return () => unsubscribe();
  }, []);

  // Fetch User Impact
  useEffect(() => {
    if (!auth.currentUser) return;
    const unsubscribe = onSnapshot(doc(db, 'impact', auth.currentUser.uid), (docSnap) => {
      if (docSnap.exists()) {
        setImpact(docSnap.data() as SustainabilityImpact);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleReserve = async (listing: FoodListing) => {
    if (!auth.currentUser || !profile) return;

    try {
      const batch = writeBatch(db);
      
      // 1. Create Order
      const orderId = doc(collection(db, 'orders')).id;
      const orderRef = doc(db, 'orders', orderId);
      
      batch.set(orderRef, {
        id: orderId,
        userId: auth.currentUser.uid,
        listingId: listing.id,
        restaurantId: listing.restaurantId,
        foodName: listing.foodName,
        status: 'pending',
        reservedAt: serverTimestamp(),
        pickupLocation: listing.address || 'Address on file', 
        pickupTime: listing.pickupTime,
        phone: listing.phone || ''
      });

      // 2. Update Listing status
      const listingRef = doc(db, 'listings', listing.id);
      batch.update(listingRef, {
        status: 'reserved'
      });

      // 3. Update Impact
      const impactRef = doc(db, 'impact', auth.currentUser.uid);
      batch.set(impactRef, {
        mealsSaved: (impact.mealsSaved || 0) + 1,
        co2Reduced: (impact.co2Reduced || 0) + 0.4,
        waterSaved: (impact.waterSaved || 0) + 120
      }, { merge: true });

      await batch.commit();

      alert(`Successfully reserved ${listing.foodName}! Please pick it up at: ${listing.address || 'the restaurant location'}. Contact: ${listing.phone || 'Check profile'}`);
    } catch (err: any) {
      console.error(err);
      alert(`Failed to reserve food: ${err.message}`);
    }
  };

  const filteredListings = listings.filter(l => 
    l.foodName.toLowerCase().includes(search.toLowerCase()) && 
    l.discountPrice <= maxPrice
  );

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Top Header */}
      <header className="h-16 bg-white border-b border-slate-200 sticky top-0 z-30 px-8 flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
            <Leaf className="text-white w-5 h-5" />
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-800">EcoPlate</span>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-full text-sm font-medium text-slate-600">
            <MapPin className="w-4 h-4 text-slate-400" />
            Brooklyn, NY
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 leading-none">Welcome Back</p>
              <p className="text-sm font-semibold text-slate-900">{profile?.name}</p>
            </div>
            <button 
              onClick={() => auth.signOut()}
              className="w-10 h-10 rounded-full bg-slate-200 border-2 border-white shadow-sm flex items-center justify-center text-slate-500 hover:text-red-500 hover:bg-red-50 transition-all overflow-hidden"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-6 grid grid-cols-12 gap-6 overflow-hidden">
        {/* Left Column: Listings */}
        <div className="col-span-12 lg:col-span-8 space-y-6 overflow-y-auto pr-2 custom-scrollbar">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-slate-800">Rescue Nearby</h1>
            <div className="flex gap-2">
              <button 
                onClick={() => setActiveTab('listings')}
                className={cn(
                  "px-4 py-2 rounded-lg text-sm font-medium transition-all border",
                  activeTab === 'listings' ? "bg-slate-900 text-white border-slate-900" : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                )}
              >
                Available Food
              </button>
              <button 
                onClick={() => setActiveTab('orders')}
                className={cn(
                  "px-4 py-2 rounded-lg text-sm font-medium transition-all border",
                  activeTab === 'orders' ? "bg-slate-900 text-white border-slate-900" : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                )}
              >
                Reserved ({orders.length})
              </button>
            </div>
          </div>

          {activeTab === 'listings' ? (
            <>
              {/* Filters */}
              <div className="flex flex-col md:flex-row gap-4 items-center">
                <div className="relative flex-1 w-full">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="text"
                    placeholder="Search for croissants, sushi, salads..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all text-sm"
                  />
                </div>
                <div className="flex items-center gap-4 bg-white p-2 rounded-xl border border-slate-200 px-4 w-full md:w-auto">
                  <Filter className="w-4 h-4 text-slate-400" />
                  <span className="text-xs font-bold text-slate-600 whitespace-nowrap">Max: ₹{maxPrice}</span>
                  <input 
                    type="range" 
                    min="100" 
                    max="2000" 
                    step="50"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(Number(e.target.value))}
                    className="w-24 accent-emerald-600"
                  />
                </div>
              </div>

              {/* Grid */}
              {filteredListings.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <AnimatePresence>
                    {filteredListings.map((listing) => (
                      <ListingCard 
                        key={listing.id} 
                        listing={listing} 
                        onReserve={() => handleReserve(listing)}
                      />
                    ))}
                  </AnimatePresence>
                </div>
              ) : (
                <div className="py-20 text-center card">
                  <Package className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                  <h3 className="font-bold text-slate-800">No rescues found</h3>
                  <p className="text-slate-500 text-sm">Try adjusting your filters or search.</p>
                </div>
              )}
            </>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {orders.length > 0 ? (
                orders.map((order) => (
                  <div key={order.id} className="card p-4 flex gap-4 items-center border-l-4 border-l-emerald-500">
                    <div className="w-12 h-12 bg-emerald-50 rounded-lg flex items-center justify-center flex-shrink-0">
                      <CheckCircle2 className="w-6 h-6 text-emerald-500" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-slate-800 leading-tight">{order.foodName}</h4>
                      <p className="text-xs text-slate-500 flex items-center gap-1 mt-1">
                        <MapPin className="w-3 h-3" /> {order.pickupLocation}
                      </p>
                      {order.phone && (
                        <p className="text-[10px] text-emerald-600 font-bold mt-1">Contact: {order.phone}</p>
                      )}
                      <div className="mt-2 flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-600 text-[10px] font-bold rounded uppercase tracking-wider">
                          {order.status}
                        </span>
                        <span className="text-[10px] text-slate-400">Reserved {new Date(order.reservedAt?.toDate()).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-2 py-20 text-center card">
                  <p className="text-slate-500 text-sm font-medium">No active reservations.</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Column: Impact & Insights */}
        <div className="col-span-12 lg:col-span-4 space-y-6">
          {/* Sustainability Dashboard */}
          <div className="card p-6 bg-slate-900 text-white border-none shadow-xl relative overflow-hidden">
            <h2 className="text-lg font-bold mb-6 flex items-center gap-2 relative z-10">
              <Leaf className="w-5 h-5 text-emerald-400" />
              Your Sustainability Impact
            </h2>
            <div className="space-y-4 relative z-10">
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-sm">Meals Saved</span>
                <span className="text-2xl font-mono font-bold text-emerald-400">{impact.mealsSaved}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-sm">CO2 Reduced</span>
                <span className="text-2xl font-mono font-bold text-emerald-400">{impact.co2Reduced.toFixed(1)} kg</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-sm">Water Saved</span>
                <span className="text-2xl font-mono font-bold text-emerald-400">{impact.waterSaved.toLocaleString()} L</span>
              </div>
              <div className="pt-4 mt-4 border-t border-slate-800">
                <div className="w-full bg-slate-800 rounded-full h-1.5 mb-2">
                  <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: `${Math.min(100, (impact.mealsSaved % 10) * 10)}%` }}></div>
                </div>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                  {10 - (impact.mealsSaved % 10)} meals until your next Waste Warrior badge
                </p>
              </div>
            </div>
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl" />
          </div>

          <div className="card p-5 space-y-4">
            <h2 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Platform Insights</h2>
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 relative">
              <div className="absolute -top-2 -right-2 px-1.5 py-0.5 bg-emerald-500 text-[8px] font-black text-white rounded flex items-center gap-1 shadow-sm uppercase tracking-tighter">
                <BrainCircuit className="w-2 h-2" />
                AI Verified
              </div>
              <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">AI Recommendation</p>
              <p className="text-sm font-bold text-slate-800 leading-tight">Rescue targets reached 85% today. Join the push!</p>
              <div className="mt-2 flex gap-1 items-center">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span className="text-[10px] text-emerald-600 font-bold uppercase">Demand High</span>
              </div>
            </div>
            <div className="bg-indigo-50 p-3 rounded-lg border border-indigo-100">
              <p className="text-[10px] font-bold text-indigo-500 uppercase mb-1">Smart Discount Active</p>
              <p className="text-xs text-indigo-900 leading-relaxed font-medium">Prices drop by <strong className="font-bold text-indigo-700">5% every 15 mins</strong> for urgent items.</p>
            </div>
          </div>

          <div className="text-center pt-2">
            <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">EcoPlate – Food Rescue v1.0.4</p>
          </div>
        </div>
      </main>
    </div>
  );
}

function ListingCard({ listing, onReserve }: { listing: FoodListing, onReserve: () => void | Promise<void>, key?: string | number }) {
  const dynamicPrice = calculateSmartDiscount(listing.originalPrice, listing.pickupTime);
  const timerClass = getTimerColor(listing.pickupTime);
  const timeLeft = formatTimeLeft(listing.pickupTime);
  const discountPercent = Math.round(((listing.originalPrice - dynamicPrice) / listing.originalPrice) * 100);
  const isUrgent = timerClass === 'timer-urgent';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className={cn(
        "card p-4 flex flex-col gap-3 transition-all hover:shadow-md",
        isUrgent ? "border-l-4 border-l-red-500" : "border-l-4 border-l-emerald-500"
      )}
    >
      <div className="flex justify-between items-start gap-4">
        <div className="w-16 h-16 bg-slate-100 rounded-lg overflow-hidden flex-shrink-0 flex items-center justify-center">
          <img 
            src={listing.imageUrl || `https://picsum.photos/seed/${listing.foodName}/100/100`} 
            alt={listing.foodName} 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className={cn("px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border", timerClass)}>
          {timeLeft}
        </div>
      </div>

      <div>
        <h3 className="font-bold text-lg leading-tight text-slate-800">{listing.foodName}</h3>
        <p className="text-xs text-slate-500 mt-1 flex items-center gap-1 font-medium">
          {listing.restaurantName} • 0.8 miles away
        </p>
      </div>

      <div className="flex items-end justify-between mt-2 pt-2 border-t border-slate-50">
        <div className="flex flex-col">
          <span className="text-[10px] text-slate-400 line-through font-bold">₹{listing.originalPrice.toFixed(2)}</span>
          <span className="text-xl font-bold text-emerald-600 font-mono tracking-tighter">₹{dynamicPrice.toFixed(2)}</span>
        </div>
        <button 
          onClick={onReserve}
          className="px-4 py-2 bg-emerald-600 text-white rounded-lg font-bold text-xs hover:bg-emerald-700 transition-all"
        >
          Reserve & Pickup
        </button>
      </div>
    </motion.div>
  );
}
