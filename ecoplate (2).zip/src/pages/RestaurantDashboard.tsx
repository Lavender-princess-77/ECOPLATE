import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Trash2, 
  Edit3, 
  Leaf, 
  LogOut, 
  BarChart3, 
  Package, 
  Clock, 
  DollarSign, 
  Image as ImageIcon,
  BrainCircuit,
  TrendingDown,
  Users,
  Building,
  MapPin,
  Phone
} from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { collection, query, where, onSnapshot, doc, addDoc, deleteDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { FoodListing, Order } from '../types';
import { useAuth } from '../components/AuthProvider';
import { predictLeftovers, cn } from '../lib/utils';

export default function RestaurantDashboard() {
  const { profile } = useAuth();
  const [listings, setListings] = useState<FoodListing[]>([]);
  const [allOrders, setAllOrders] = useState<Order[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  
  // AI Prediction state
  const [orderCount, setOrderCount] = useState(45);
  const [timeOfDay, setTimeOfDay] = useState(18); // 6 PM
  const [prediction, setPrediction] = useState(0);

  // Form state
  const [foodName, setFoodName] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [originalPrice, setOriginalPrice] = useState(500);
  const [discountPrice, setDiscountPrice] = useState(250);
  const [pickupTime, setPickupTime] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [uploading, setUploading] = useState(false);

  // Handle File Upload (PNG/JPEG)
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!['image/jpeg', 'image/png'].includes(file.type)) {
      alert('Please upload a PNG or JPEG image.');
      return;
    }

    setUploading(true);
    const reader = new FileReader();
    reader.onloadend = () => {
      setImageUrl(reader.result as string);
      setUploading(false);
    };
    reader.readAsDataURL(file);
  };

  // Fetch Listings
  useEffect(() => {
    if (!auth.currentUser) return;
    const q = query(collection(db, 'listings'), where('restaurantId', '==', auth.currentUser.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as FoodListing[];
      setListings(docs);
    });
    return () => unsubscribe();
  }, []);

  // Fetch All Orders for this restaurant
  useEffect(() => {
    if (!auth.currentUser) return;
    const q = query(collection(db, 'orders'), where('restaurantId', '==', auth.currentUser.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as Order[];
      setAllOrders(docs);
    });
    return () => unsubscribe();
  }, []);

  // Run AI Prediction
  useEffect(() => {
    setPrediction(predictLeftovers(orderCount, timeOfDay));
  }, [orderCount, timeOfDay]);

  const handleAddListing = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser || !profile) return;

    try {
      const newListing = {
        restaurantId: auth.currentUser.uid,
        restaurantName: profile.name,
        address: profile.address || '',
        phone: profile.phone || '',
        foodName,
        quantity,
        originalPrice,
        discountPrice,
        pickupTime: new Date(pickupTime).toISOString(),
        imageUrl: imageUrl || `https://picsum.photos/seed/${foodName}/600/400`,
        status: 'available',
        createdAt: serverTimestamp()
      };

      await addDoc(collection(db, 'listings'), newListing);
      setIsAdding(false);
      resetForm();
    } catch (err) {
      console.error(err);
      alert('Failed to create listing');
    }
  };

  const resetForm = () => {
    setFoodName('');
    setQuantity(1);
    setOriginalPrice(20);
    setDiscountPrice(10);
    setPickupTime('');
    setImageUrl('');
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this listing?')) {
      await deleteDoc(doc(db, 'listings', id));
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="h-16 bg-white border-b border-slate-200 sticky top-0 z-30 px-8 flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
            <Leaf className="text-white w-5 h-5" />
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-800">EcoPlate</span>
          <span className="text-[10px] font-black uppercase tracking-widest px-2 py-0.5 bg-slate-100 text-slate-500 rounded-full ml-2">Restaurant</span>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 leading-none">Restaurant Account</p>
              <p className="text-sm font-semibold text-slate-900">{profile?.name}</p>
            </div>
            <button 
              onClick={() => auth.signOut()}
              className="w-10 h-10 rounded-full bg-slate-200 border-2 border-white shadow-sm flex items-center justify-center text-slate-500 hover:text-red-500 hover:bg-red-50 transition-all"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto w-full p-6 grid grid-cols-12 gap-6 overflow-hidden">
        {/* Left Column: Stats & Prediction */}
        <div className="col-span-12 lg:col-span-4 space-y-6">
          {/* AI Advisor Card */}
          <section className="card p-6 bg-slate-900 text-white border-none shadow-xl relative overflow-hidden">
                <div className="flex items-center justify-between mb-2 relative z-10">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center animate-pulse">
                      <BrainCircuit className="w-5 h-5 text-white" />
                    </div>
                    <h2 className="text-lg font-bold tracking-tight">AI Surplus Advisor</h2>
                  </div>
                  <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-[8px] font-black uppercase tracking-widest rounded border border-emerald-500/30">Smart AI</span>
                </div>
                <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-6 relative z-10">Powered by Machine Learning</p>

             <div className="space-y-6 relative z-10">
               <div className="space-y-4">
                 <div className="flex justify-between text-[10px] uppercase tracking-widest font-bold text-slate-400">
                   <span>Daily Orders</span>
                   <span className="text-emerald-400 font-mono">{orderCount}</span>
                 </div>
                 <input 
                   type="range" 
                   min="0" max="200" 
                   value={orderCount} 
                   onChange={(e) => setOrderCount(Number(e.target.value))}
                   className="w-full accent-emerald-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                 />
               </div>

               <div className="space-y-4">
                 <div className="flex justify-between text-[10px] uppercase tracking-widest font-bold text-slate-400">
                   <span>Peak Hour (24h)</span>
                   <span className="text-emerald-400 font-mono">{timeOfDay}:00</span>
                 </div>
                 <input 
                   type="range" 
                   min="0" max="23" 
                   value={timeOfDay} 
                   onChange={(e) => setTimeOfDay(Number(e.target.value))}
                   className="w-full accent-emerald-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                 />
               </div>

               <div className="pt-6 mt-6 border-t border-slate-800">
                  <p className="text-[10px] uppercase tracking-widest font-bold text-emerald-500 mb-2">Real-time Surplus Risk</p>
                  <div className="flex items-baseline gap-2">
                    <p className="text-5xl font-mono font-bold leading-none">{prediction}</p>
                    <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Meals</p>
                  </div>
                  
                  {/* AI Actionable Insights */}
                  <div className="mt-6 bg-white/5 border border-white/5 rounded-xl p-4 space-y-3">
                    <p className="text-[9px] font-black text-emerald-400 uppercase tracking-widest flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      AI Intelligence Report
                    </p>
                    <div className="space-y-2">
                      <div className="flex justify-between text-[10px]">
                        <span className="text-slate-500">Inventory Turnover</span>
                        <span className="text-white font-bold">{orderCount > 150 ? 'Excellent' : 'Moderate'}</span>
                      </div>
                      <div className="flex justify-between text-[10px]">
                        <span className="text-slate-500">Closing Volatility</span>
                        <span className={timeOfDay > 18 ? "text-orange-400 font-bold" : "text-emerald-400 font-bold"}>
                          {timeOfDay > 18 ? 'High (spiking)' : 'Stable'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <p className="mt-4 text-slate-400 text-[10px] leading-relaxed font-medium italic">
                    "AI detects {timeOfDay > 18 ? 'elevated' : 'normal'} surplus potential based on closing volatility. Action recommended."
                  </p>
               </div>
             </div>
             <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl" />
          </section>

          {/* Business Info Display */}
          <section className="card p-6 border-slate-100 bg-white shadow-sm">
             <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 leading-tight">Business Profile</h3>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Verified Restaurant</p>
                </div>
                <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center">
                  <Building className="w-4 h-4 text-slate-400" />
                </div>
             </div>
             
             <div className="space-y-4">
                <div className="flex gap-3">
                  <div className="mt-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-300" />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Pickup Location</p>
                    <p className="text-xs font-semibold text-slate-700 leading-snug">{profile?.address || 'Address not listed'}</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="mt-1">
                    <Phone className="w-3.5 h-3.5 text-slate-300" />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Support Contact</p>
                    <p className="text-xs font-semibold text-slate-700">{profile?.phone || 'Phone not listed'}</p>
                  </div>
                </div>
             </div>
          </section>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 gap-4">
            <div className="card p-5">
              <TrendingDown className="w-6 h-6 text-emerald-500 mb-3" />
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest leading-none mb-1">Active</p>
              <p className="text-2xl font-mono font-bold text-slate-900">{listings.length}</p>
            </div>
            <div className="card p-5">
              <Users className="w-6 h-6 text-indigo-500 mb-3" />
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest leading-none mb-1">Impact</p>
              <p className="text-2xl font-mono font-bold text-slate-900">{allOrders.length}</p>
            </div>
          </div>

          <div className="card p-5 bg-emerald-50 border-emerald-100">
             <div className="flex gap-3">
               <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0">
                  <Leaf className="w-4 h-4 text-emerald-600" />
               </div>
               <div>
                 <p className="text-xs font-bold text-emerald-800">Eco-Score Excellence</p>
                 <p className="text-[10px] text-emerald-600 mt-0.5 leading-relaxed">Your restaurant is in the top 10% of local rescuers this week.</p>
               </div>
             </div>
          </div>
        </div>

        {/* Right Column: Listings */}
        <div className="col-span-12 lg:col-span-8 space-y-6">
           <div className="flex justify-between items-center">
             <h2 className="text-2xl font-bold text-slate-800 tracking-tight leading-none">Management Console</h2>
             <button 
               onClick={() => setIsAdding(true)}
               className="px-4 py-2 bg-slate-900 text-white rounded-lg flex items-center gap-2 hover:bg-slate-800 transition-all shadow-sm text-sm font-bold"
             >
               <Plus className="w-4 h-4" />
               List Surplus
             </button>
           </div>

           {/* Add Listing Modal */}
           <AnimatePresence>
             {isAdding && (
               <motion.div 
                 initial={{ opacity: 0, y: 10 }}
                 animate={{ opacity: 1, y: 0 }}
                 exit={{ opacity: 0, y: 10 }}
                 className="card p-8 shadow-2xl relative overflow-hidden bg-white border-slate-200"
               >
                 <div className="flex justify-between items-center mb-6">
                   <h3 className="text-xl font-bold text-slate-900">New Surplus Listing</h3>
                   <button onClick={() => setIsAdding(false)} className="text-slate-400 hover:text-slate-900 transition-colors">
                     <Plus className="w-5 h-5 rotate-45" />
                   </button>
                 </div>
                 
                 <form onSubmit={handleAddListing} className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div className="space-y-1.5 md:col-span-2">
                       <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block ml-1">Food Item Name</label>
                       <div className="relative">
                         <Package className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                         <input required type="text" value={foodName} onChange={(e) => setFoodName(e.target.value)} placeholder="e.g. Avocado Toast" className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all text-sm font-medium" />
                       </div>
                    </div>
                    <div className="space-y-1.5">
                       <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block ml-1">Quantity</label>
                       <input required type="number" value={quantity} onChange={(e) => setQuantity(Number(e.target.value))} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-bold text-sm" />
                    </div>
                    <div className="space-y-1.5">
                       <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block ml-1">Pickup Deadline</label>
                       <input required type="datetime-local" value={pickupTime} onChange={(e) => setPickupTime(e.target.value)} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-bold text-sm" />
                    </div>
                    <div className="space-y-1.5">
                       <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block ml-1">Original Price (₹)</label>
                       <div className="relative">
                          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">₹</span>
                          <input required type="number" value={originalPrice} onChange={(e) => setOriginalPrice(Number(e.target.value))} className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-bold text-sm" />
                       </div>
                    </div>
                    <div className="space-y-1.5">
                       <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block ml-1 text-emerald-600">Base Rescue Price (₹)</label>
                       <div className="relative">
                          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-400 font-bold">₹</span>
                          <input required type="number" value={discountPrice} onChange={(e) => setDiscountPrice(Number(e.target.value))} className="w-full pl-10 pr-4 py-3 bg-emerald-50 border border-emerald-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-bold text-emerald-700 text-sm" />
                       </div>
                    </div>
                    <div className="space-y-1.5 md:col-span-2">
                       <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block ml-1">Food Photo (PNG/JPEG)</label>
                       <div className="flex gap-4 items-center">
                          <label className="flex-1 cursor-pointer">
                            <div className="w-full px-4 py-3 bg-slate-50 border border-dashed border-slate-300 rounded-xl hover:bg-slate-100 transition-all flex items-center justify-center gap-2">
                               <ImageIcon className="w-4 h-4 text-slate-400" />
                               <span className="text-sm font-medium text-slate-600">{uploading ? 'Processing...' : 'Click to upload menu photo'}</span>
                            </div>
                            <input type="file" accept="image/png, image/jpeg" onChange={handleFileChange} className="hidden" />
                          </label>
                          {imageUrl && (
                            <div className="w-12 h-12 rounded-lg overflow-hidden border border-slate-200 bg-white">
                               <img src={imageUrl} alt="Preview" className="w-full h-full object-cover" />
                            </div>
                          )}
                       </div>
                    </div>
                    
                    <div className="md:col-span-2 flex gap-4 pt-4">
                       <button type="submit" className="flex-1 py-3.5 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 shadow-xl shadow-slate-900/10 transition-all">Publish Live Rescue</button>
                    </div>
                 </form>
               </motion.div>
             )}
           </AnimatePresence>

           {/* Listings Management */}
           <div className="grid grid-cols-1 gap-4">
             {listings.length > 0 ? (
               listings.map((listing) => (
                 <div key={listing.id} className="card p-4 flex flex-col md:flex-row gap-4 items-center">
                   <div className="w-16 h-16 rounded-lg overflow-hidden bg-slate-100 flex-shrink-0">
                      <img src={listing.imageUrl} alt={listing.foodName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                   </div>
                   <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-bold text-lg text-slate-800 leading-tight">{listing.foodName}</h4>
                        <span className={cn(
                          "px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest border",
                          listing.status === 'available' ? "bg-emerald-50 text-emerald-600 border-emerald-100" : "bg-blue-50 text-blue-600 border-blue-100"
                        )}>
                          {listing.status}
                        </span>
                      </div>
                      <div className="flex gap-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                         <span className="flex items-center gap-1"><Package className="w-3 h-3 opacity-50" /> {listing.quantity} left</span>
                         <span className="flex items-center gap-1"><Clock className="w-3 h-3 opacity-50" /> {new Date(listing.pickupTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                   </div>
                   <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-lg font-mono font-bold text-slate-900 tracking-tighter leading-none">₹{listing.discountPrice.toFixed(2)}</p>
                        <p className="text-[10px] font-bold text-slate-300 line-through leading-none mt-1">₹{listing.originalPrice.toFixed(2)}</p>
                      </div>
                      <div className="flex gap-1.5">
                        <button className="w-10 h-10 flex items-center justify-center bg-slate-50 text-slate-400 rounded-lg hober:bg-slate-100 hover:text-slate-600 transition-all border border-slate-100">
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDelete(listing.id)} className="w-10 h-10 flex items-center justify-center bg-slate-50 text-slate-400 rounded-lg hover:bg-red-50 hover:text-red-500 transition-all border border-slate-100">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                   </div>
                 </div>
               ))
             ) : (
                <div className="py-20 text-center card border-dashed border-2 bg-slate-50 border-slate-200 shadow-none">
                  <Package className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                  <h3 className="font-bold text-slate-800">No active rescues</h3>
                  <p className="text-slate-500 text-sm mt-1">List your surplus food to start saving the planet.</p>
                  <button 
                    onClick={() => setIsAdding(true)}
                    className="mt-6 px-6 py-2 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-100 transition-all"
                  >
                    Quick Start Guide
                  </button>
                </div>
             )}
           </div>
        </div>
      </main>
    </div>
  );
}
