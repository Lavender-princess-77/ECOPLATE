import React from 'react';
import { motion } from 'motion/react';
import { Leaf, Utensils, Timer, ShieldCheck, Heart } from 'lucide-react';
import { cn } from '../lib/utils';

interface LandingProps {
  onGetStarted: () => void;
}

export default function Landing({ onGetStarted }: LandingProps) {
  return (
    <div className="flex flex-col min-h-screen bg-slate-50">
      {/* Navigation */}
      <nav className="p-8 flex justify-between items-center bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
            <Leaf className="text-white w-5 h-5" />
          </div>
          <span className="text-2xl font-bold tracking-tight text-slate-800">EcoPlate</span>
        </div>
        <button 
          onClick={onGetStarted}
          className="px-6 py-2.5 bg-slate-900 text-white rounded-lg text-sm font-bold hover:bg-slate-800 transition-all shadow-sm"
        >
          Sign In
        </button>
      </nav>

      {/* Hero Section */}
      <section className="relative px-6 pt-24 pb-32 flex flex-col items-center text-center max-w-5xl mx-auto overflow-hidden">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-8 relative z-10"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-600 text-[10px] font-black uppercase tracking-widest mb-4">
            <ShieldCheck className="w-3 h-3" /> Over 12k Meals Rescued Globally
          </div>
          <h1 className="text-7xl md:text-9xl font-bold text-slate-900 leading-[0.88] tracking-tighter">
            Rescue <span className="text-emerald-500">Delicious</span> <br />
            Food Nearby.
          </h1>
          <p className="max-w-2xl mx-auto text-lg md:text-xl text-slate-500 font-medium leading-relaxed">
            EcoPlate connects you with local restaurants to save surplus meals. 
            Fresh food, incredible prices, huge impact.
          </p>
          <div className="pt-8">
            <button 
              onClick={onGetStarted}
              className="px-12 py-5 bg-emerald-600 text-white rounded-xl text-xl font-bold hover:bg-emerald-700 transition-all shadow-xl hover:shadow-2xl shadow-emerald-600/20 active:translate-y-0.5"
            >
              Start Rescuing Now
            </button>
          </div>
        </motion.div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-24 w-full relative z-10">
           <FeatureCard 
             icon={<Timer className="w-5 h-5 text-emerald-600" />}
             title="Rescue Timers"
             description="Time-sensitive discounts that increase as pickup windows approach."
           />
           <FeatureCard 
             icon={<Utensils className="w-5 h-5 text-emerald-600" />}
             title="Restaurant Network"
             description="Verified local gems listing surplus delicacies at up to 75% off."
           />
           <FeatureCard 
             icon={<ShieldCheck className="w-5 h-5 text-indigo-600" />}
             title="AI Predictions"
             description="Smart waste monitoring for restaurants to optimize preparation."
             isAi={true}
           />
        </div>
        
        {/* Background Decorative */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-emerald-100/30 rounded-full blur-3xl -z-10" />
      </section>

      {/* Impact Section */}
      <section className="bg-slate-900 py-32 text-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-24 items-center relative z-10">
          <div className="space-y-8">
            <h2 className="text-5xl md:text-6xl font-bold leading-[0.9] tracking-tight">Every Plate Counts for our Planet.</h2>
            <p className="text-slate-400 text-lg leading-relaxed max-w-lg">
              Food waste is a leading driver of climate change. 
              Rescuing one meal saves enough water for 100 showers and reduces carbon footprint significantly.
            </p>
            <div className="flex gap-12 pt-4">
              <div>
                <span className="block text-5xl font-mono font-bold text-emerald-400">12,482</span>
                <span className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em] mt-2 block">Meals Saved Today</span>
              </div>
              <div>
                <span className="block text-5xl font-mono font-bold text-emerald-400">4,9t</span>
                <span className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em] mt-2 block">CO2 Reduced</span>
              </div>
            </div>
          </div>
          <div className="card p-1 bg-slate-800 border-slate-700 shadow-2xl relative">
            <div className="relative aspect-[4/3] rounded-lg overflow-hidden group">
              <img 
                src="https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&q=80&w=1200" 
                alt="Healthy food" 
                className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-x-0 bottom-0 p-6 bg-gradient-to-t from-slate-900/90 to-transparent">
                 <div className="flex items-center gap-2 mb-2">
                    <Heart className="w-4 h-4 text-emerald-400 fill-emerald-400" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">Join the movement</span>
                 </div>
                 <p className="text-lg font-bold leading-tight">Small actions multiplied by millions can transform the world.</p>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute -bottom-48 -right-48 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl opacity-50" />
      </section>

      {/* Footer */}
      <footer className="p-16 bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="flex flex-col items-center md:items-start gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-emerald-500 rounded flex items-center justify-center">
                <Leaf className="text-white w-4 h-4" />
              </div>
              <span className="text-xl font-bold tracking-tight text-slate-800">EcoPlate</span>
            </div>
            <p className="text-slate-400 text-xs font-medium">Fighting food waste with intelligent rescue.</p>
          </div>
          <div className="flex gap-12 text-slate-500 text-[10px] font-bold uppercase tracking-widest">
            <a href="#" className="hover:text-emerald-600 transition-colors">Privacy</a>
            <a href="#" className="hover:text-emerald-600 transition-colors">Terms</a>
            <a href="#" className="hover:text-emerald-600 transition-colors">Contact</a>
          </div>
          <p className="text-slate-300 text-[10px] font-bold uppercase tracking-widest">© 2026 EcoPlate. v1.0.4</p>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description, isAi = false }: { icon: React.ReactNode, title: string, description: string, isAi?: boolean }) {
  return (
    <div className={cn(
      "card p-8 flex flex-col items-start text-left transition-all hover:shadow-lg",
      isAi && "bg-indigo-50/30 border-indigo-100"
    )}>
      <div className={cn(
        "w-12 h-12 rounded-xl flex items-center justify-center mb-6 border",
        isAi ? "bg-indigo-50 border-indigo-100" : "bg-emerald-50 border-emerald-100"
      )}>
        {icon}
      </div>
      <div className="flex items-center gap-2 mb-3">
        <h3 className="text-xl font-bold text-slate-900">{title}</h3>
        {isAi && <span className="badge-ai px-1.5 py-0.5 rounded text-[8px] font-bold uppercase tracking-tight">AI Active</span>}
      </div>
      <p className="text-slate-500 leading-relaxed text-sm font-medium">{description}</p>
    </div>
  );
}
