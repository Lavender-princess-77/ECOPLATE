/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'user' | 'restaurant';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  address?: string;
  phone?: string;
  createdAt: any;
}

export interface FoodListing {
  id: string;
  restaurantId: string;
  restaurantName: string;
  address?: string;
  phone?: string;
  foodName: string;
  quantity: number;
  originalPrice: number;
  discountPrice: number;
  pickupTime: string; // ISO string
  imageUrl: string;
  status: 'available' | 'reserved' | 'sold';
  createdAt: any;
}

export interface Order {
  id: string;
  userId: string;
  listingId: string;
  restaurantId: string;
  foodName: string;
  status: 'pending' | 'completed' | 'cancelled';
  reservedAt: any;
  pickupLocation?: string;
  pickupTime?: string;
}

export interface SustainabilityImpact {
  mealsSaved: number;
  co2Reduced: number; // in kg
  waterSaved: number; // in liters
}
