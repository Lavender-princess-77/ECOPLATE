/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './components/AuthProvider';
import Landing from './pages/Landing';
import AuthPage from './pages/Auth';
import UserDashboard from './pages/UserDashboard';
import RestaurantDashboard from './pages/RestaurantDashboard';
import { motion, AnimatePresence } from 'motion/react';

function AppContent() {
  const { user, profile, loading } = useAuth();
  const [view, setView] = useState<'landing' | 'auth'>('landing');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-stone-50">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  // Route determining logic
  let activePage: React.ReactNode;

  if (user && profile) {
    if (profile.role === 'restaurant') {
      activePage = <RestaurantDashboard />;
    } else {
      activePage = <UserDashboard />;
    }
  } else if (view === 'auth') {
    activePage = <AuthPage onBack={() => setView('landing')} />;
  } else {
    activePage = <Landing onGetStarted={() => setView('auth')} />;
  }

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 font-sans">
      <AnimatePresence mode="wait">
        <motion.main
          key={user ? profile?.role : view}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3 }}
        >
          {activePage}
        </motion.main>
      </AnimatePresence>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
