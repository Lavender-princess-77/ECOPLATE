import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { differenceInMinutes, parseISO } from 'date-fns';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * AI Waste Prediction (Refined Model)
 * Predicts leftover meals using a non-linear curve based on 
 * order volume and time-of-day volatility.
 */
export function predictLeftovers(orders: number, timeOfDay: number): number {
  // Base Surplus: higher orders generally mean better planning but higher potential for fixed waste
  const baseSurplus = 15;
  
  // Volume Factor: Inverse relationship - more orders usually means more efficiency (lower % waste)
  const volumeEfficiency = Math.max(0.1, 1 - (orders / 250));
  
  // Time Factor: Waste risk spikes as we approach closing (assumed 22:00)
  // We use a parabolic curve: risk = (t - peak)^2
  const peakEfficiencyHour = 13; // 1 PM
  const timeVolatility = Math.pow((timeOfDay - peakEfficiencyHour), 2) / 40;
  
  const totalPrediction = (baseSurplus + (orders * 0.15)) * volumeEfficiency * (1 + timeVolatility);
  
  return Math.max(2, Math.round(totalPrediction));
}

/**
 * Smart Discount Logic
 * Increases discount as pickup time approaches
 */
export function calculateSmartDiscount(originalPrice: number, pickupTimeISO: string): number {
  const now = new Date();
  const pickupDate = parseISO(pickupTimeISO);
  const minutesLeft = differenceInMinutes(pickupDate, now);
  
  let discountPercentage = 10; // Base 10%
  
  if (minutesLeft <= 0) {
    discountPercentage = 90; // Flash sale if expired/urgent
  } else if (minutesLeft <= 30) {
    discountPercentage = 70;
  } else if (minutesLeft <= 60) {
    discountPercentage = 50;
  } else if (minutesLeft <= 120) {
    discountPercentage = 30;
  }
  
  const discountAmount = originalPrice * (discountPercentage / 100);
  return Number((originalPrice - discountAmount).toFixed(2));
}

export function getTimerColor(pickupTimeISO: string): string {
  const now = new Date();
  const pickupDate = parseISO(pickupTimeISO);
  const minutesLeft = differenceInMinutes(pickupDate, now);
  
  if (minutesLeft <= 30) return 'timer-urgent';
  if (minutesLeft <= 90) return 'timer-moderate';
  return 'timer-safe';
}

export function formatTimeLeft(pickupTimeISO: string): string {
  const now = new Date();
  const pickupDate = parseISO(pickupTimeISO);
  const minutesLeft = differenceInMinutes(pickupDate, now);
  
  if (minutesLeft <= 0) return 'Pickup expired';
  
  const hours = Math.floor(minutesLeft / 60);
  const minutes = minutesLeft % 60;
  
  if (hours > 0) {
    return `${hours}h ${minutes}m left`;
  }
  return `${minutes}m left`;
}
