# EcoPlate Security Specification

## Data Invariants
1. A Listing must have a valid `restaurantId` matching the creating user's UID.
2. An Order must have a valid `userId` matching the creating user's UID.
3. Users can only update their own profile and impact data.
4. Listings can only be updated/deleted by the restaurant that created them.
5. Discount prices must be less than or equal to original prices.

## The "Dirty Dozen" Payloads (Denial Tests)
1. **Identity Spoofing (Listing)**: User A creates a listing with `restaurantId` of User B. -> REJECT
2. **Identity Spoofing (User Profile)**: User A updates User B's profile. -> REJECT
3. **Privilege Escalation**: User registers as "admin" role (not a real role here, but test it). -> REJECT
4. **State Skip**: User tries to set Order status to "completed" without going through "pending". -> REJECT
5. **Ghost Field Injection**: User tries to add `isVerified: true` to their user profile. -> REJECT
6. **Path Poisoning**: Providing a 2KB string as `documentId`. -> REJECT
7. **Negative Price**: Setting `discountPrice` to -10. -> REJECT
8. **Invalid Status**: Setting Listing status to "deleted" (not in enum). -> REJECT
9. **Timestamp Trick**: Setting `createdAt` to a future date manually. -> REJECT
10. **Listing Takeover**: User A tries to change the `restaurantId` of an existing listing. -> REJECT
11. **Orphaned Order**: Creating an Order for a listing that doesn't exist. -> REJECT
12. **Sustainability Fraud**: User tries to increment `mealsSaved` by 1000 manually. -> REJECT
